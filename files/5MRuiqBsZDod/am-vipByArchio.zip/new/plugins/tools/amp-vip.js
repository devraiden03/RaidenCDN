/*
 * plugins/tools/amp-vip.js
 * Fitur: AM Premium VIP (Injector Alight Motion via ampremium.eu.cc).
 * Menerima konteks `ctx` dari src/core/konteks.js; dijalankan sesudah semua
 * gerbang & middleware raidenai-cmd.js.
 *
 * Alur kerja (2 langkah, magic link):
 *   1. .ampvip send <email>   → bot minta tautan verifikasi dikirim ke email
 *   2. (buka email, salin tautan panjang dari alightcreative.com)
 *   3. .ampvip verif <tautan> → bot verifikasi & aktifkan premium 1 tahun
 *
 * Perintah bantu:
 *   .ampvip            → tampilkan panduan
 *   .ampvip status     → cek sesi yang sedang menunggu verifikasi
 *   .ampvip batal      → hapus sesi yang tertunda
 */
import tierAkses from '../../src/lib/tiers.js';

const pluginConfig = {
  name: 'amp-vip',
  category: 'tools',
  command: ['ampvip', 'amprem', 'amppremium'],
};

const handler = async (m, ctx) => {
  const { Reply, args, command, daftar, isVip, prefix, raiden, safeErr, text } = ctx;

  // ── Gerbang: wajib terdaftar (kecuali VIP) ──
  if (!isRegistered(m.sender) && !isVip) return daftar(global.mess.verifikasi);

  const p = `${prefix}${command}`;
  const sub = (args[0] || '').toLowerCase();
  const rest = args.slice(1).join(' ').trim();

  const panduan =
    `🎬 *AM PREMIUM VIP — Injector Alight Motion*\n` +
    `Aktifkan Premium Alight Motion lewat tautan ajaib (magic link).\n\n` +
    `*ALUR PEMAKAIAN:*\n` +
    `① *Kirim tautan ke email*\n` +
    `   \`${p} send emailkamu@gmail.com\`\n\n` +
    `② *Buka email kamu* (cek inbox/spam), salin tautan panjang dari *alightcreative.com*\n\n` +
    `③ *Verifikasi tautan*\n` +
    `   \`${p} verif https://alightcreative.com/...\`\n\n` +
    `*PERINTAH LAIN:*\n` +
    `• \`${p} status\` — cek sesi yang menunggu\n` +
    `• \`${p} batal\` — hapus sesi tertunda\n\n` +
    `_Satu email = satu akun premium. Simpan email & sandinya._`;

  // ── Tanpa argumen → panduan ──
  if (!sub) return Reply(panduan);

  // ── Muat modul scraper ──
  let amp;
  try {
    amp = (await import('../../src/scraper/ampvip.js')).default;
  } catch (e) {
    console.error('[amp-vip] gagal muat scraper:', e);
    return Reply(`❌ Modul AM Premium gagal dimuat: ${safeErr(e)}`);
  }

  // ── Subperintah: STATUS ──
  if (['status', 'cek', 'info'].includes(sub)) {
    const s = amp.getSession(m.sender);
    if (!s || !s.pending) {
      return Reply(`ℹ️ Tidak ada sesi tertunda.\nMulai dengan:\n\`${p} send emailkamu@gmail.com\``);
    }
    return Reply(
      `📋 *Sesi AM Premium*\n\n` +
      `• Email : ${s.email}\n` +
      `• Status : ⏳ Menunggu verifikasi tautan\n` +
      `• Diminta : ${s.requestedAt ? new Date(s.requestedAt).toLocaleString('id-ID') : '-'}\n\n` +
      `Lanjutkan:\n\`${p} verif <tautan dari email>\``
    );
  }

  // ── Subperintah: BATAL ──
  if (['batal', 'cancel', 'reset', 'hapus'].includes(sub)) {
    const ada = amp.clearSession(m.sender);
    return Reply(ada ? '🗑️ Sesi tertunda dihapus.' : 'ℹ️ Tidak ada sesi untuk dihapus.');
  }

  // ── Subperintah: SEND (langkah 1) ──
  if (['send', 'kirim', 'req', 'request'].includes(sub)) {
    const email = rest.split(/\s+/)[0] || '';
    if (!email) {
      return Reply(`❌ Masukkan email.\n\nContoh:\n\`${p} send emailkamu@gmail.com\``);
    }
    if (!amp.isEmail(email)) {
      return Reply(`❌ Format email tidak valid: *${email}*\n\nContoh:\n\`${p} send emailkamu@gmail.com\``);
    }

    // Konsumsi limit hanya saat aksi nyata ke API.
    if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip)) return Reply(global.mess.limit);

    await raiden.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
      const res = await amp.requestLink(email);
      if (!res.ok) {
        await raiden.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        return Reply(`❌ Gagal mengirim tautan: ${res.why}`);
      }

      amp.saveSession(m.sender, { email: email.trim(), pending: true, requestedAt: new Date().toISOString() });
      await raiden.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
      return Reply(
        `✅ *Tautan terkirim ke ${email}*\n` +
        `${res.message}\n\n` +
        `📩 *Langkah berikutnya:*\n` +
        `1. Buka email kamu (cek *inbox* / *spam*)\n` +
        `2. Salin tautan panjang dari *alightcreative.com*\n` +
        `3. Kirim:\n   \`${p} verif <tautan>\`\n\n` +
        `_Tautan berlaku terbatas, segera verifikasi._`
      );
    } catch (e) {
      console.error('[amp-vip] send error:', e);
      await raiden.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      return Reply(`❌ Terjadi kesalahan: ${safeErr(e)}`);
    }
  }

  // ── Subperintah: VERIF (langkah 2) ──
  if (['verif', 'verify', 'verifikasi', 'suntik', 'inject'].includes(sub)) {
    // Dukung dua bentuk:
    //   .ampvip verif <link>                (email diambil dari sesi)
    //   .ampvip verif <email>|<link>        (eksplisit)
    let email = '';
    let link = '';

    if (rest.includes('|')) {
      const [a, b] = rest.split('|').map((x) => x.trim());
      email = a; link = b;
    } else {
      link = rest;
      const s = amp.getSession(m.sender);
      if (s && s.email) email = s.email;
    }

    if (!link) {
      return Reply(
        `❌ Masukkan tautan dari email.\n\n` +
        `Contoh:\n\`${p} verif https://alightcreative.com/...\`\n\n` +
        `_Kirim tautan dulu? → \`${p} send emailkamu@gmail.com\`_`
      );
    }
    if (!email) {
      return Reply(
        `❌ Email tidak ditemukan di sesi.\n\n` +
        `Gunakan salah satu:\n` +
        `• \`${p} send emailkamu@gmail.com\` dulu, lalu verif\n` +
        `• \`${p} verif emailkamu@gmail.com|https://alightcreative.com/...\``
      );
    }
    if (!amp.isHttpUrl(link)) {
      return Reply(`❌ Tautan tidak valid. Harus diawali *http://* atau *https://*`);
    }

    // Konsumsi limit hanya saat aksi nyata ke API.
    if (!checkAndConsumeLimit(m.sender, tierAkses.isPrem(m.sender), isVip)) return Reply(global.mess.limit);

    await raiden.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    try {
      const res = await amp.verifyLink(email, link);
      if (!res.ok) {
        await raiden.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        return Reply(`❌ Injeksi gagal: ${res.why}`);
      }

      amp.clearSession(m.sender);
      await raiden.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
      return Reply(
        `✅ *INJEKSI SUKSES!*\n\n` +
        `Premium telah diaktifkan untuk akun:\n*${email}*\n\n` +
        `${res.message}\n\n` +
        `🎉 Selamat menikmati Alight Motion Premium!\n` +
        `_© ${global.botname}_`
      );
    } catch (e) {
      console.error('[amp-vip] verif error:', e);
      await raiden.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      return Reply(`❌ Terjadi kesalahan saat verifikasi: ${safeErr(e)}`);
    }
  }

  // ── Subperintah tak dikenal ──
  return Reply(
    `❓ Subperintah *${sub}* tidak dikenal.\n\n${panduan}`
  );
};

export default handler;
