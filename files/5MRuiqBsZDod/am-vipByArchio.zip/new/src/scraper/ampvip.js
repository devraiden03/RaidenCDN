// File: src/scraper/ampvip.js
// AM Premium VIP (ampremium.eu.cc) — Magic-link Injector Scraper
// Alur 2 langkah: request-link  →  (user tempel link dari email)  →  verify-link
// Direkonstruksi dari capture HAR NetHawk. Gaya mengikuti src/scraper/alight.js
// ═══════════════════════════════════════════════════════════

import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ─── Konfigurasi ─────────────────────────────────────────
const cfg = {
  base: 'https://ampremium.eu.cc',
  epRequest: '/api/request-link',
  epVerify: '/api/verify-link',
  timeout: 30000,
  // Fingerprint persis dari capture HAR (biar sidik jari klien dikenal server).
  ua: 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
  acceptLang: 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
};

// ─── Logger ──────────────────────────────────────────────
const log = {
  info:    (m) => console.log(`[AMPVIP] ${m}`),
  success: (m) => console.log(`[AMPVIP] ✅ ${m}`),
  warn:    (m) => console.warn(`[AMPVIP] ⚠️ ${m}`),
  error:   (m) => console.error(`[AMPVIP] ❌ ${m}`),
};

// ─── Database sesi (keyed by WhatsApp sender JID) ────────
const DATA_DIR = path.join(__dirname, 'database');
const DB_SESSIONS = path.join(DATA_DIR, 'ampvip_sessions.json');

function ensureDatabase() {
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    if (!fs.existsSync(DB_SESSIONS)) fs.writeFileSync(DB_SESSIONS, JSON.stringify({}, null, 2));
  } catch (e) {
    log.error(`Gagal membuat database: ${e.message}`);
  }
}
ensureDatabase();

function readSessions() {
  try { return JSON.parse(fs.readFileSync(DB_SESSIONS, 'utf8')); }
  catch { return {}; }
}
function writeSessions(data) {
  try { fs.writeFileSync(DB_SESSIONS, JSON.stringify(data, null, 2)); return true; }
  catch (e) { log.error(`Gagal simpan sesi: ${e.message}`); return false; }
}

function saveSession(jid, data) {
  const s = readSessions();
  s[jid] = { ...(s[jid] || {}), ...data, savedAt: new Date().toISOString() };
  writeSessions(s);
  return s[jid];
}
function getSession(jid) {
  const s = readSessions();
  return s[jid] || null;
}
function clearSession(jid) {
  const s = readSessions();
  if (s[jid]) { delete s[jid]; writeSessions(s); return true; }
  return false;
}

// ─── Validasi ────────────────────────────────────────────
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const isEmail = (e) => typeof e === 'string' && EMAIL_RE.test(e.trim());
const isHttpUrl = (u) => {
  if (typeof u !== 'string' || !u.trim()) return false;
  try { new URL(u.trim()); return /^https?:\/\//i.test(u.trim()); } catch { return false; }
};

// ─── Helper POST JSON (header sesuai HAR) ────────────────
async function postJson(endpoint, body) {
  const url = cfg.base + endpoint;
  try {
    const res = await axios.post(url, body, {
      timeout: cfg.timeout,
      headers: {
        'Content-Type': 'application/json',
        Accept: '*/*',
        'User-Agent': cfg.ua,
        'Accept-Language': cfg.acceptLang,
        Origin: cfg.base,
        Referer: cfg.base + '/',
      },
      // Jangan lempar untuk status < 500 — tangani payload-nya manual.
      validateStatus: (s) => s >= 200 && s < 500,
    });
    return { httpStatus: res.status, data: res.data };
  } catch (err) {
    const d = err.response?.data;
    return {
      httpStatus: err.response?.status || 0,
      data: null,
      error: d?.error || d?.message || err.message || 'Request gagal',
    };
  }
}

// ─── Langkah 1: minta magic link dikirim ke email ────────
/**
 * @param {string} email
 * @returns {Promise<{ok: boolean, message?: string, why?: string, raw?: any}>}
 */
async function requestLink(email) {
  if (!isEmail(email)) return { ok: false, why: 'Email tidak valid' };
  const addr = email.trim();
  log.info(`Minta magic link untuk: ${addr}`);

  const { data, error } = await postJson(cfg.epRequest, { email: addr });
  if (error && !data) return { ok: false, why: error };

  if (data && data.success === true) {
    log.success('Magic link terkirim');
    return { ok: true, message: data.message || 'Tautan berhasil dikirim.', raw: data };
  }
  return { ok: false, why: data?.error || data?.message || 'Gagal mengirim tautan', raw: data };
}

// ─── Langkah 2: verifikasi magic link (aktivasi premium) ─
/**
 * @param {string} email
 * @param {string} link  magic link dari inbox email (alightcreative.com/...)
 * @returns {Promise<{ok: boolean, message?: string, why?: string, raw?: any}>}
 */
async function verifyLink(email, link) {
  if (!isEmail(email)) return { ok: false, why: 'Email tidak valid' };
  if (!isHttpUrl(link)) return { ok: false, why: 'Link tidak valid (harus diawali http/https)' };
  const addr = email.trim();
  const magic = link.trim();
  log.info(`Verifikasi magic link untuk: ${addr}`);

  const { data, error } = await postJson(cfg.epVerify, { email: addr, link: magic });
  if (error && !data) return { ok: false, why: error };

  if (data && data.success === true) {
    log.success(`Premium diaktifkan: ${addr}`);
    return { ok: true, message: data.message || 'Premium berhasil diaktifkan.', raw: data };
  }
  return { ok: false, why: data?.error || data?.message || 'Verifikasi gagal / link tidak valid', raw: data };
}

// ─── Exports ─────────────────────────────────────────────
export default {
  requestLink,
  verifyLink,
  saveSession,
  getSession,
  clearSession,
  isEmail,
  isHttpUrl,
  ensureDatabase,
  API_BASE: cfg.base,
};
export {
  requestLink,
  verifyLink,
  saveSession,
  getSession,
  clearSession,
  isEmail,
  isHttpUrl,
  ensureDatabase,
};
